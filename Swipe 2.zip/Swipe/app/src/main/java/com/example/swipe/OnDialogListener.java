package com.example.swipe;
public interface OnDialogListener {
    void onFinish(int position, Person person);
}

