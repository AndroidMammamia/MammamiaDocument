package com.example.swipe;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Activity_First extends AppCompatActivity {

    ImageButton addrbtn, geobtn;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        addrbtn = findViewById(R.id.addr_btn);
        geobtn =findViewById(R.id.geo_btn);

        addrbtn.setOnClickListener(onClickListener);
        geobtn.setOnClickListener(onClickListener);
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            switch (v.getId()){
                case R.id.addr_btn:
                    Intent intent = new Intent(Activity_First.this, Activity_AddrLIst.class);
                    startActivity(intent);
                    break;
            }
        }
    };
}
